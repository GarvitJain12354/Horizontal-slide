function servicelocomotive() {
  gsap.registerPlugin(ScrollTrigger);

  // Using Locomotive Scroll from Locomotive https://github.com/locomotivemtl/locomotive-scroll

  const locoScroll = new LocomotiveScroll({
    el: document.querySelector("#service"),
    smooth: true,
    //   multiplier: 0.3,
  });
  // each time Locomotive Scroll updates, tell ScrollTrigger to update too (sync positioning)
  locoScroll.on("scroll", ScrollTrigger.update);

  // tell ScrollTrigger to use these proxy methods for the ".smooth-scroll" element since Locomotive Scroll is hijacking things
  ScrollTrigger.scrollerProxy("#service", {
    scrollTop(value) {
      return arguments.length
        ? locoScroll.scrollTo(value, 0, 0)
        : locoScroll.scroll.instance.scroll.y;
    }, // we don't have to define a scrollLeft because we're only scrolling vertically.
    getBoundingClientRect() {
      return {
        top: 0,
        left: 0,
        width: window.innerWidth,
        height: window.innerHeight,
      };
    },
    // LocomotiveScroll handles things completely differently on mobile devices - it doesn't even transform the container at all! So to get the correct behavior and avoid jitters, we should pin things with position: fixed on mobile. We sense it by checking to see if there's a transform applied to the container (the LocomotiveScroll-controlled element).
    pinType: document.querySelector("#service").style.transform
      ? "transform"
      : "fixed",
  });

  // each time the window updates, we should refresh ScrollTrigger and then update LocomotiveScroll.
  ScrollTrigger.addEventListener("refresh", () => locoScroll.update());

  // after everything is set up, refresh() ScrollTrigger and update LocomotiveScroll because padding may have been added for pinning, etc.
  ScrollTrigger.refresh();
}
servicelocomotive();
const data = [
    {
      img: "./assests/service/Group 213.png",
      name: "ADR",
      para1: `Sound Disposition has 2 well-specified ADR suites in Soho, London,
        where we have had the honour of recording ADR and VO for a wide
        range of films and episodic drama including`,
      bold: `  Miniature Gallery of ADR projects in portrait format, clicking on
        any takes you through to ADR project portfolio page`,
      para2: `   We also offer ADR and voice supervision services including spotting,
        charting, scheduling and casting`,
      para3: "To read more about our range of ADR services click here.",
      a: "/",
    },
    {
      img: "./assests/service/remote.jpeg",
      name: "Remote ADR",
      para1: `Sound Disposition was one of the first companies to offer a comprehensive remote ADR offering. The systems we developed during the pandemic have been refined through hundreds of hours of sessions and are now a preferred option for some talent and productions. `,
      bold: "",
      para2: `  Our offering encompasses a range of options for productions where the artist is unable or unwilling to travel to a studio, including setups which travels to the location with an engineer, shippable rigs, and even remote studio configuration.`,
      para3:
        "We are experts at remote connectivity and can stream sessions over virtually any relay method in areas with little or no internet or phone reception. We were the first company to offer ADR via Starlink.",
      a: "/",
    },
    {
      img: "./assests/service/remote.jpeg",
      name: "Sound Design",
      para1: `We’re passionate about finding the right sound for the moment - whether it’s creating original sounds using our phenomenal range of software, hardware, microphones, foley props and instruments; or tracklaying sound effects from our vast and ever-growing library. `,
      bold: "",
      para2: `At Sound Disposition we pay particular attention to the subtle art of supporting the image. Through careful layering of complex atmospheres and also subtle soundscapes (along with the usual bangs, whooshes, explosions and crashes!) we aim to shape the audience’s subconscious appreciation of the narrative through sound design.`,
      para3: `We believe every project should have a unique and original sound, and therefore we insist on sourcing our own sounds for each film we work on. 
        `,
      a: "/",
    },
    {
      img: "./assests/service/remote.jpeg",
      name: "Dialogue Editing ",
      para1: `We place the utmost importance in the dialogue edit. It’s potentially the most valuable element of film sound and therefore a great dialogue edit can revolutionise a film’s soundtrack.
        `,
      bold: "",
      para2: `rx, izotope, sound disposition, dialogue, editing, edit, marc, specter, kraken, pro tools, We use a cutting-edge set of processes to reduce background noise and improve flow whilst being sensitive to maintain performances. This is done on top of the basic clean-up edit of the production sound. We employ custom software including the top-secret Kraken™ (programmed by Marc Specter) and as a result you’ll have your audio seamlessly transferred into our systems, whatever format you’ve shot or edited in.`,
      para3: `We consider ourselves workflow specialists and therefore can conform sessions others can’t! `,
      a: "/",
    },
    {
      img: "./assests/service/remote.jpeg",
      name: "Mixing",
      para1: `In our custom-built mixing suites we are equipped to mix in virtually any format, including Dolby Atmos, and higher-order ambisonics, as well as 7.1, 5.1 and stereo.
        `,
      bold: "",
      para2: `As well as client-attended sessions, we can also offer remote mixing for clients located elsewhere via a number of advanced relay methods. We are also experts at cinema upmixing of content, ensuring your work translates perfectly to the big screen.`,
      para3: `Mixing is the culmination of the sound post-production process. It takes the audience by the hand and leads them through the narrative, shaping and sculpting their appreciation of the film. `,
      a: "/",
    },
    {
      img: "./assests/service/foley.png",
      name: "Foley",
      para1: `Our foley team work in a custom-built foley stage with a plethora of props and surfaces, ready to create any sound you can conceive (and many you can’t)`,
      bold: "",
      para2: `Foley is an incredibly important part of what we do. It’s one of the many tools we use to fastidiously support the story, and therefore we go to great lengths to ensure that our work is the best it can be.foley
        `,
      para3: `The studio recently welcomed the addition of our new foley room. Fully floated and sound proof, the space contains a range of surfaces for all circumstances. We can create anything from specific pickups to full a foley pass either in-house or using external artists. We possess an extensive range of shoes and clothing along with a wide range of props and devices, and as a result we can create any sound you can imagine!`,
      a: "/",
    },
    {
      img: "./assests/service/foley.png",
      name: "Immersive, Interactive & VR",
      para1: `Our foley team work in a custom-built foley stage with a plethora of props and surfaces, ready to create any sound you can conceive (and many you can’t)`,
      bold: "",
      para2: `Foley is an incredibly important part of what we do. It’s one of the many tools we use to fastidiously support the story, and therefore we go to great lengths to ensure that our work is the best it can be.foley
        `,
      para3: `The studio recently welcomed the addition of our new foley room. Fully floated and sound proof, the space contains a range of surfaces for all circumstances. We can create anything from specific pickups to full a foley pass either in-house or using external artists. We possess an extensive range of shoes and clothing along with a wide range of props and devices, and as a result we can create any sound you can imagine!`,
      a: "/",
    },
    {
      img: "./assests/service/foley.png",
      name: "Sound Effect Recording",
      para1: "",
      bold: "",
      para2: "",
      para3: "",
      a: "/",
    },
    {
      img: "./assests/service/foley.png",
      name: "Site-specific Soundscapes",
      para1: "",
      bold: "",
      para2: "",
      para3: "",
      a: "/",
    },
    {
      img: "./assests/service/foley.png",
      name: "Podcasts and Audio Books",
      para1: "",
      bold: "",
      para2: "",
      para3: "",
      a: "/",
    },
    {
      img: "./assests/service/foley.png",
      name: "Sonic Branding, Idents",
      para1: "",
      bold: "",
      para2: "",
      para3: "",
      a: "/",
    },
  ];
function servicecard() {
 

  var index = 0;
  var clutter = "";

  clutter = `
<img src='${data[index].img}' alt="" />
<h1>${data[index].name}</h1>
<h3>
  ${data[index].para1}
</h3>
${
  data[index].bold !== ""
    ? `
<div class="flex">
<div class="cir">
  <div class="fill"></div>
</div>
<h2>
  ${data[index].bold}
</h2>
</div>
`
    : ""
}

<h3>
${data[index].para2}
</h3>
<h3>${data[index].para3}</h3>
<button><a href='${data[index].a}'>Read More<img id="blackimg" src="./assests/service/right.svg" alt=""> <img id="leftwhite" src="./assests/service/trending_flat_FILL0_wght400_GRAD0_opsz48.png" alt=""></a></button>`;



  document.querySelector(".white").innerHTML = clutter;

  document.querySelectorAll(".name").forEach(function (elem) {
    elem.addEventListener("click", () => {
      // console.log(elem.getAttribute("data-index"));
      index = elem.getAttribute("data-index");
      clutter = `
<img src='${data[index].img}' alt="" />
<h1>${data[index].name}</h1>
<h3>
  ${data[index].para1}
</h3>
${
  data[index].bold !== ""
    ? `
<div class="flex">
<div class="cir">
  <div class="fill"></div>
</div>
<h2>
  ${data[index].bold}
</h2>
</div>
`
    : ""
}

<h3>
${data[index].para2}
</h3>
<h3>${data[index].para3}</h3>
<button><a href='${
        data[index].a
      }'>Read More <img src="./assests/right.svg" alt=""> <img id="leftwhite" src="./assests/trending_flat_FILL0_wght400_GRAD0_opsz48.png" alt=""></a></button>
`;

      document.querySelector(".white").innerHTML = clutter;
    });
  });
}
servicecard();

window.addEventListener("resize",()=>{
    if(window.innerWidth < 820){
        console.log("hello");
    }
})



var swiper = new Swiper("#service .mySwiper", {
  loop:true,
  autoplay: {
    delay: 2500,
    disableOnInteraction: false
  },
  pagination: {
    el: ".swiper-pagination",
    clickable: true
  },
 
});